package fundamentals;

public class Sum {
	public static void main(String[] args) {
		int a,b,c;
		a=10;
		b=15;
		c=a+b;
		System.out.println(c);
	}
}
