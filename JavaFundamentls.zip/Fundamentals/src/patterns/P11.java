package patterns;
import java.util.*;
public class P11 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		for(int i=1;i<=n;i++) 
		{
			int a=i;
			for(int j=0;j<i;j++) 
			{
				System.out.print(a);
				a--;
			}
			System.out.println();
		}
	}
}
